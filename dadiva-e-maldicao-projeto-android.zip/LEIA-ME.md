# Dádiva e Maldição — projeto Android (APK)

Este projeto empacota o jogo `dadiva-e-maldicao.html` em um app Android (WebView, tela cheia).
O Bitrise gera o APK automaticamente.

## Como usar

1. Descompacte este `.zip`.
2. Envie **todos os arquivos** para a **raiz** do repositório `brisite` no GitHub,
   ao lado do `dadiva-e-maldicao.html` (não mexa nesse arquivo).
   - No GitHub: *Add file → Upload files* → arraste tudo → *Commit changes*.
   - Importante: envie também as pastas `app/` (com a estrutura interna).
3. No Bitrise, rode o workflow **primary** (ou peça para o Claude disparar o build).
4. Quando terminar, baixe o APK em **Artifacts** (`dadiva-e-maldicao.apk`).

## Instalar no celular

Baixe o APK no celular e permita "instalar apps de fontes desconhecidas" quando o Android pedir.

## Observações

- O APK é de **debug** (assinado com chave de teste), serve para instalar e jogar direto.
  Para publicar na Play Store seria preciso um APK/AAB de release assinado.
- Para atualizar o jogo, é só trocar o `dadiva-e-maldicao.html` no repositório e rodar o build de novo.
- Se o Bitrise guardar o `bitrise.yml` no site (e não no repositório), copie o conteúdo deste arquivo
  para a aba *Workflows → bitrise.yml* do app.
